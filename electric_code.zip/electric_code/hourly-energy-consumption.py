#!/usr/bin/env python
# coding: utf-8

# - In this kernel I will provide all the steps required for doing time series analysis using time series data and simple RNN, LSTM models.
# - You can see the performance of simple RNN model, LSTM model and compare their performance.
# 
# ## 1. Basic step

# In[1]:


import os
import numpy as np
import pandas as pd
import tensorflow as tf
import matplotlib.pyplot as plt
import sklearn.preprocessing
from sklearn.metrics import r2_score

from keras.layers import Dense,Dropout,SimpleRNN,LSTM
from keras.models import Sequential



# ## 2. Data loading and data exploration
# 
# - **Load the data file**

# In[2]:


#choosing DOM_hourly.csv data for analysis
fpath='./AEP_hourly.csv'

df=pd.read_csv(fpath)
df.columns = ["datetime", "mwh"]
# df.head()


# - **Change the index of rows in the dataframe from 0,1,2... to datetime (2005-12-31 01:00:00,...)**
# 
# **Why should we change the index of rows?**<br>
# Because we are dealing with time series data and we will need the datetime data to recognize a particular record.

# In[3]:


#Let's use datetime(2012-10-01 12:00:00,...) as index instead of numbers(0,1,...)
#This will be helpful for further data analysis as we are dealing with time series data
df = pd.read_csv(fpath, parse_dates=['Datetime'])
df.columns = ["datetime", "mwh"]
df = df.sort_values(["datetime"])
df = df.set_index("datetime")
# df.head()


# - **Check if there are missing values in the data loaded**

# In[4]:


#checking missing data
# df.isna().sum()


# Since there is no missing data in the data loaded we will not be dropping the missing value records or will not be imputing the data. We will proceed with the further data analysis.
# 
# - **Data visualization**

# In[5]:


# df.plot(figsize=(16,4),legend=True)

# plt.title('AEP hourly power consumption data - BEFORE NORMALIZATION')

# plt.show()


# - **Normalize data**
# - Before proceeding with further data analysis we must ensure that the data is normalized. 
# - For this we will be using [sklearn MinMaxScaler](https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.MinMaxScaler.html)

# In[6]:


def normalize_data(df):
    scaler = sklearn.preprocessing.MinMaxScaler()
    df['mwh']=scaler.fit_transform(df['mwh'].values.reshape(-1,1))
    return df

df_norm = normalize_data(df)
# df_norm.shape


# - **Visualize data after normalization**
# - After normalization the range of power consumption values changes which we can observe on the **y-axis** of the graph. In the earlier graph that was displayed it was in the range **0 - 22500**
# - Now after normalization we can observe that the data range on **y-axis** is **0.0 - 1.0**

# In[7]:


# df_norm.plot(figsize=(16,4),legend=True)

# plt.title('AEP hourly power consumption data - AFTER NORMALIZATION')

# plt.show()


# In[8]:


# df_norm.shape


# ## 3. Prepare data for training the RNN models

# In[9]:


def load_data(stock, seq_len):
    X_train = []
    y_train = []
    for i in range(seq_len, len(stock)):
        X_train.append(stock.iloc[i-seq_len : i, 0])
        y_train.append(stock.iloc[i, 0])
    
    #1 last 6189 days are going to be used in test
    X_test = X_train[110000:]             
    y_test = y_train[110000:]
    
    #2 first 110000 days are going to be used in training
    X_train = X_train[:110000]           
    y_train = y_train[:110000]
    
    #3 convert to numpy array
    X_train = np.array(X_train)
    y_train = np.array(y_train)
    
    X_test = np.array(X_test)
    y_test = np.array(y_test)
    
    #4 reshape data to input into RNN models
    X_train = np.reshape(X_train, (110000, seq_len, 1))
    
    X_test = np.reshape(X_test, (X_test.shape[0], seq_len, 1))
    
    return [X_train, y_train, X_test, y_test]


# **To get an understanding on how sequence length is useful in training RNN models refer to the following links:**
# - https://stackoverflow.com/questions/49573242/what-is-sequence-length-in-lstm
# - https://stats.stackexchange.com/questions/158834/what-is-a-feasible-sequence-length-for-an-rnn-to-model

# In[10]:


#create train, test data
seq_len = 20 #choose sequence length

X_train, y_train, X_test, y_test = load_data(df, seq_len)

print('X_train.shape = ',X_train.shape)
print('y_train.shape = ', y_train.shape)
print('X_test.shape = ', X_test.shape)
print('y_test.shape = ',y_test.shape)


# ## 5. Build an LSTM model

# In[11]:


lstm_model = Sequential()

lstm_model.add(LSTM(40,activation="tanh",return_sequences=True, input_shape=(X_train.shape[1],1)))
lstm_model.add(Dropout(0.15))

lstm_model.add(LSTM(40,activation="tanh",return_sequences=True))
lstm_model.add(Dropout(0.15))

lstm_model.add(LSTM(40,activation="tanh",return_sequences=False))
lstm_model.add(Dropout(0.15))

lstm_model.add(Dense(1))

lstm_model.summary()


# In[12]:


lstm_model.compile(optimizer="adam",loss="MSE")
lstm_model.fit(X_train, y_train, epochs=10, batch_size=1000)


# - **Let's check r2 score for the values predicted by the above trained LSTM model**

# In[13]:


lstm_predictions = lstm_model.predict(X_test)

lstm_score = r2_score(y_test, lstm_predictions)
print("R^2 Score of LSTM model = ",lstm_score)


# - **Let's compare the actual values vs predicted values by plotting a graph**

# In[15]:


# def plot_predictions(test, predicted, title):
#     plt.figure(figsize=(16,4))
#     plt.plot(test, color='blue',label='Actual power consumption data')
#     plt.plot(predicted, alpha=0.7, color='orange',label='Predicted power consumption data')
#     plt.title(title)
#     plt.xlabel('Time')
#     plt.ylabel('Normalized power consumption scale')
#     plt.legend()
#     plt.show()
    
# plot_predictions(y_test, lstm_predictions, "Predictions made by LSTM model")


# **References:**
# - https://www.kaggle.com/thebrownviking20/everything-you-can-do-with-a-time-series
# - https://www.kaggle.com/thebrownviking20/intro-to-recurrent-neural-networks-lstm-gru
